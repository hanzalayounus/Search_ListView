package com.search.listview.app.search_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
